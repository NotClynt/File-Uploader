<?php

// UPLOADER
define('DIRECTORY', "");
define('DOMAIN', "%domain%");
define('SHOW_IP', "false");


// EMBED
define('EMBED', true, true);
define('EMBED_TITLE', "%service_name%", true);
define('EMBED_DESCRIPTION', "https://github.com/clynt707/File-Uploader", true);
define('EMBED_COLOUR', "%embed_color%", true);

// URLs
define('BASE_DOMAIN', "%base_domain%");
define('CDN_URL', "%cdn_url%");
define('DISCORD_INVITE', "%discord_invite%");


// SEO
define('EMBED_COLOR', "%embed_color%");
define('DESCRIPTION', "%description%");
define('KEYWORDS', "%keywords%");


// WEBSITE
define('SERVICE_NAME', "%service_name%");
define('SERVICE_DESCRIPTION', "%service_description%");