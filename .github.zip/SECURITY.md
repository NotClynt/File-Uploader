# Security Policy

## Supported php Versions

| Version | Supported          |
| ------- | ------------------ |
| 7.0.x   | :x:                | 
| 8.0.x   | :white_check_mark: |

## Reporting a Vulnerability

Contact me on Discord Clynt#6169
It usually takes 1 day after the report for an answer 
